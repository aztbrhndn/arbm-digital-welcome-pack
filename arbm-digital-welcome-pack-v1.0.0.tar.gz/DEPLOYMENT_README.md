# ARBM Digital Welcome Pack - Deployment Package

## Package Information
- **Version**: 1.0.0
- **Build Date**: 2025-07-09T04:50:15.784Z
- **Package Type**: Intranet Static Deployment
- **Developer**: Adhis
- **Client**: Al Rajhi Bank Malaysia (ARBM)

## Quick Deployment Guide

### Option 1: Apache Web Server
1. Extract all files to your web server document root
2. Ensure the `.htaccess` file is present and enabled
3. Access `index.html` through your web browser

### Option 2: IIS Web Server
1. Extract all files to your IIS site directory
2. The `web.config` file will handle proper MIME types
3. Access `index.html` through your web browser

### Option 3: Nginx Web Server
1. Extract all files to your nginx document root
2. Include the provided nginx configuration snippet
3. Access `index.html` through your web browser

### Option 4: Simple Static Server
1. Extract all files to any directory
2. Run a simple HTTP server:
   - Python: `python3 -m http.server 8000`
   - Node.js: `npx http-server -p 8000`
   - PHP: `php -S localhost:8000`

## File Structure
```
arbm-digital-welcome-pack/
├── index.html              # Main presentation entry point
├── css/                    # Custom styles and themes
├── js/                     # Custom JavaScript functionality
├── assets/                 # Images, icons, and media files
├── lib/                    # Optimized libraries (Reveal.js, plugins)
├── server-configs/         # Server configuration files
├── build-info.json         # Build and deployment information
├── DEPLOYMENT_README.md    # This file
└── DEPLOYMENT_CHECKLIST.md # Deployment verification checklist
```

## Browser Compatibility
- Chrome 70+
- Firefox 65+
- Safari 12+
- Edge 79+
- Mobile Safari 12+
- Chrome Mobile 70+

## Security Considerations
- All files are static (no server-side processing required)
- No external dependencies or CDN requirements
- Suitable for secure intranet environments
- No data collection or external communication

## Troubleshooting
1. **Presentation not loading**: Check browser console for errors
2. **Menu not appearing**: Verify JavaScript is enabled
3. **Matterport not loading**: Update the tour URL in `js/custom.js`
4. **Mobile issues**: Ensure touch events are enabled

## Support
- **Documentation**: README.md (full documentation)
- **Developer**: Adhis
- **Project**: ARBM Digital Welcome Pack

## Updates
To update content:
1. Edit `index.html` for slide content
2. Modify `css/custom.css` for styling
3. Update `js/custom.js` for functionality
4. Replace files in `assets/` for media updates

For detailed instructions, see the main README.md file.
